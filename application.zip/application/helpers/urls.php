<?php

function get_url(){

}

function redirect(){
	header(...);
}